﻿define({
    root: {
    },
    "zh-cn":true
});