﻿define(
   ({
    _widgetLabel: "Basiskaartgalerij"
  })
);