﻿define(
   ({
    _widgetLabel: "Galleri over baggrundskort"
  })
);