﻿define(
   ({
    _widgetLabel: "Galleri för baskartor"
  })
);