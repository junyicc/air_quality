﻿define(
   ({
    _widgetLabel: "Galeria map bazowych"
  })
);