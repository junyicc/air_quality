﻿define(
   ({
    _widgetLabel: "Συλλογή υποβάθρων"
  })
);