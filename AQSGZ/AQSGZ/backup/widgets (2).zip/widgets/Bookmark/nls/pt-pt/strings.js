﻿define(
   ({
    labelBookmarkName: "Adicionar a vista atual aos marcadores",
    labelPlay: "Reproduzir Todos",
    labelStop: "Parar",
    labelDelete: "Eliminar",
    placeholderBookmarkName: "Nome do Marcador",
    errorNameExist: "O Marcador existe!",
    errorNameNull: "Nome de marcador inválido!",
    _widgetLabel: "Marcador"
  })
);