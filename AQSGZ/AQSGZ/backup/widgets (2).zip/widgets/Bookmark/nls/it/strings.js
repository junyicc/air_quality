﻿define(
   ({
    labelBookmarkName: "Aggiungi segnalibro per visualizzazione corrente",
    labelPlay: "Riproduci tutto",
    labelStop: "Arresta",
    labelDelete: "Elimina",
    placeholderBookmarkName: "Nome segnalibro",
    errorNameExist: "Segnalibro esistente.",
    errorNameNull: "Nome segnalibro non valido.",
    _widgetLabel: "Segnalibro"
  })
);