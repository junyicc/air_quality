﻿define(
   ({
    labelBookmarkName: "Žymėti dabartinį vaizdą",
    labelPlay: "Leisti viską",
    labelStop: "Stabdyti",
    labelDelete: "Pašalinti",
    placeholderBookmarkName: "Žymės pavadinimas",
    errorNameExist: "Žymė yra!",
    errorNameNull: "Neleistinas žymės pavadinimas!",
    _widgetLabel: "Žymės"
  })
);