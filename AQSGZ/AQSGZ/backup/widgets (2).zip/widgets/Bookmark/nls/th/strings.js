﻿define(
   ({
    labelBookmarkName: "สร้างบุคมาร์คในมุมมองปัจจุบัน",
    labelPlay: "เล่นทั้งหมด",
    labelStop: "หยุด",
    labelDelete: "ลบทิ้ง",
    placeholderBookmarkName: "ตั้งชื่อบุคมาร์ค",
    errorNameExist: "บุคมาร์คมีอยู่แล้ว!",
    errorNameNull: "ชื่อบุคมาร์คไม่ถูกต้อง!",
    _widgetLabel: "ที่คั่น"
  })
);