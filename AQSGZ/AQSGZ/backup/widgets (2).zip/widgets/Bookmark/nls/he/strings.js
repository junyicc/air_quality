﻿define(
   ({
    labelBookmarkName: "הוסף את התצוגה הנוכחית למועדפים",
    labelPlay: "נגן הכל",
    labelStop: "עצור",
    labelDelete: "מחק",
    placeholderBookmarkName: "שם סימניה",
    errorNameExist: "סימניה קיימת!",
    errorNameNull: "שם סימניה לא חוקי!",
    _widgetLabel: "סימנייה"
  })
);