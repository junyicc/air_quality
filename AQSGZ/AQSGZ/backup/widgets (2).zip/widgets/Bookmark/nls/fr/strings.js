﻿define(
   ({
    labelBookmarkName: "Créer un géosignet pour la vue courante",
    labelPlay: "Lire tout",
    labelStop: "Arrêter",
    labelDelete: "Supprimer",
    placeholderBookmarkName: "Nom du géosignet",
    errorNameExist: "Le géosignet existe !",
    errorNameNull: "Nom de géosignet non valide !",
    _widgetLabel: "Géosignet"
  })
);