﻿define(
   ({
    labelBookmarkName: "Pievienot pašreizējo skatu grāmatzīmēm",
    labelPlay: "Atskaņot visu",
    labelStop: "Apturēt",
    labelDelete: "Dzēst",
    placeholderBookmarkName: "Grāmatzīmes nosaukums",
    errorNameExist: "Grāmatzīme pastāv!",
    errorNameNull: "Nederīgs grāmatzīmes nosaukums.",
    _widgetLabel: "Grāmatzīme"
  })
);