﻿define(
   ({
    labelBookmarkName: "标记当前视图",
    labelPlay: "播放所有",
    labelStop: "停止",
    labelDelete: "删除",
    placeholderBookmarkName: "书签名称",
    errorNameExist: "书签已存在!",
    errorNameNull: "书签名称无效!",
    _widgetLabel: "书签"
  })
);