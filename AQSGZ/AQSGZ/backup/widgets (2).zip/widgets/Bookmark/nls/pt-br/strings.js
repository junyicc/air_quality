﻿define(
   ({
    labelBookmarkName: "Marcar a visualização atual",
    labelPlay: "Reproduzir Todos",
    labelStop: "Parar",
    labelDelete: "Excluir",
    placeholderBookmarkName: "Nome do Marcador",
    errorNameExist: "O marcador existe!",
    errorNameNull: "Nome de marcador inválido!",
    _widgetLabel: "Marcador"
  })
);