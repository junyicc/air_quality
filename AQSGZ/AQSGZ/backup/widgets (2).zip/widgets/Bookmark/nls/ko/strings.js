﻿define(
   ({
    labelBookmarkName: "현재 뷰에 책갈피 설정",
    labelPlay: "모두 재생",
    labelStop: "중지",
    labelDelete: "삭제",
    placeholderBookmarkName: "책갈피 이름",
    errorNameExist: "책갈피가 있습니다.",
    errorNameNull: "잘못된 책갈피 이름입니다.",
    _widgetLabel: "책갈피"
  })
);