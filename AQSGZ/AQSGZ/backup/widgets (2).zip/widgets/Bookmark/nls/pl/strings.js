﻿define(
   ({
    labelBookmarkName: "Dodaj zakładkę do bieżącego widoku",
    labelPlay: "Odtwórz wszystko",
    labelStop: "Zatrzymaj",
    labelDelete: "Usuń",
    placeholderBookmarkName: "Nazwa zakładki",
    errorNameExist: "Zakładka już istnieje!",
    errorNameNull: "Nieprawidłowa nazwa zakładki!",
    _widgetLabel: "Zakładka"
  })
);