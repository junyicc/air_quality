﻿define(
   ({
    labelBookmarkName: "Skapa ett bokmärke för den aktuella vyn",
    labelPlay: "Spela alla",
    labelStop: "Stoppa",
    labelDelete: "Ta bort",
    placeholderBookmarkName: "Skapa ett bokmärke för namn",
    errorNameExist: "Det finns ett bokmärke!",
    errorNameNull: "Ogiltigt namn på bokmärke!",
    _widgetLabel: "Bokmärke"
  })
);