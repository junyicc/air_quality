﻿define(
   ({
    labelBookmarkName: "Lisa praegune vaade järjehoidjasse",
    labelPlay: "Esita kõik",
    labelStop: "Lõpeta",
    labelDelete: "Kustuta",
    placeholderBookmarkName: "Järjehoidja nimi",
    errorNameExist: "Järjehoidja on olemas!",
    errorNameNull: "Vigane järjehoidja nimi!",
    _widgetLabel: "Järjehoidja"
  })
);