﻿define(
   ({
    labelBookmarkName: "現在のビューをブックマークに登録",
    labelPlay: "すべてを再生",
    labelStop: "停止",
    labelDelete: "削除",
    placeholderBookmarkName: "ブックマーク名",
    errorNameExist: "すでに存在しているブックマーク名です",
    errorNameNull: "無効なブックマーク名です",
    _widgetLabel: "ブックマーク"
  })
);