﻿define(
   ({
    labelBookmarkName: "Bladwijzer maken voor de huidige weergave",
    labelPlay: "Alles afspelen",
    labelStop: "Stoppen",
    labelDelete: "Verwijderen",
    placeholderBookmarkName: "Naam van bladwijzer",
    errorNameExist: "Bladwijzer bestaat al.",
    errorNameNull: "Ongeldige naam van bladwijzer.",
    _widgetLabel: "Bladwijzer"
  })
);