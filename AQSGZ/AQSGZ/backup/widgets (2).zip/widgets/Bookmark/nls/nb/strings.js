﻿define(
   ({
    labelBookmarkName: "Bokmerk gjeldende visning",
    labelPlay: "Spill alle",
    labelStop: "Stopp",
    labelDelete: "Slett",
    placeholderBookmarkName: "Bokmerkenavn",
    errorNameExist: "Bokmerket eksisterer.",
    errorNameNull: "Ugyldig bokmerkenavn.",
    _widgetLabel: "Bokmerke"
  })
);