﻿define(
   ({
    add: "单击以添加新书签",
    title: "标题",
    placeholderBookmarkName: "书签名称",
    ok: "确定",
    cancel: "取消",
    warning: "请完成此编辑!",
    edit: "编辑书签",
    errorNameExist: "书签已存在!",
    errorNameNull: "书签名称无效!",
    addBookmark: "创建新书签",
    thumbnail: "缩略图",
    thumbnailHint: "单击影像进行更新"
  })
);