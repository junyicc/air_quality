﻿define(
   ({
    add: "Lisää uusi kirjanmerkki napsauttamalla",
    title: "Otsikko",
    placeholderBookmarkName: "Kirjanmerkin nimi",
    ok: "OK",
    cancel: "Peruuta",
    warning: "Viimeistele muokkaus.",
    edit: "Muokkaa kirjanmerkkiä",
    errorNameExist: "Kirjanmerkki on olemassa!",
    errorNameNull: "Kirjanmerkin nimi on virheellinen!",
    addBookmark: "Luo uusi kirjanmerkki",
    thumbnail: "Pikkukuva",
    thumbnailHint: "Päivitä napsauttamalla kuvaa"
  })
);