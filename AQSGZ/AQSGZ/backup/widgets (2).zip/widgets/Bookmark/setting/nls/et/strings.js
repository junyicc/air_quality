﻿define(
   ({
    add: "Klikkige uue järjehoidja lisamiseks",
    title: "Pealkiri",
    placeholderBookmarkName: "Järjehoidja nimi",
    ok: "OK",
    cancel: "Tühista",
    warning: "Viige muutmine lõpule!",
    edit: "Muuda järjehoidjat",
    errorNameExist: "Järjehoidja on olemas!",
    errorNameNull: "Vigane järjehoidja nimi!",
    addBookmark: "Loo uus järjehoidja",
    thumbnail: "Pisipilt",
    thumbnailHint: "Klikkige uuendamiseks pilti"
  })
);