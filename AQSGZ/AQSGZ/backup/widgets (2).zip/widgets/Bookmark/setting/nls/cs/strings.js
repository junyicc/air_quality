﻿define(
   ({
    add: "Kliknutím přidáte novou záložku.",
    title: "Nadpis",
    placeholderBookmarkName: "Název záložky",
    ok: "OK",
    cancel: "Zrušit",
    warning: "Dokončete úpravu!",
    edit: "Upravit záložku",
    errorNameExist: "Záložka již existuje!",
    errorNameNull: "Neplatný název záložky!",
    addBookmark: "Vytvořit novou záložku",
    thumbnail: "Miniatura",
    thumbnailHint: "Kliknutím na obrázek jej aktualizujete."
  })
);