﻿define(
   ({
    add: "Paspauskite norėdami pridėti naują žymę",
    title: "Pavadinimas",
    placeholderBookmarkName: "Žymės pavadinimas",
    ok: "Gerai",
    cancel: "Atšaukti",
    warning: "Baikite redagavimą!",
    edit: "Redaguoti žymę",
    errorNameExist: "Žymė yra!",
    errorNameNull: "Neleistinas žymės pavadinimas!",
    addBookmark: "Kurti naują žymę",
    thumbnail: "Miniatiūra",
    thumbnailHint: "Paspauskite vaizdą norėdami atnaujinti"
  })
);