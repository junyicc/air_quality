﻿define(
   ({
    add: "انقر لإضافة علامة مرجعية جديدة",
    title: "عنوان",
    placeholderBookmarkName: "اسم الإشارة المرجعية",
    ok: "موافق",
    cancel: "إلغاء الأمر",
    warning: "يرجى إنهاء التحرير!",
    edit: "حرر العلامة المرجعية",
    errorNameExist: "الإشارات المرجعية موجودة!",
    errorNameNull: "اسم إشارة مرجعية غير صحيح!",
    addBookmark: "إنشاء إشارة مرجعية جديدة",
    thumbnail: "صورة مصغرة",
    thumbnailHint: "انقر على الصورة لتحديثها"
  })
);