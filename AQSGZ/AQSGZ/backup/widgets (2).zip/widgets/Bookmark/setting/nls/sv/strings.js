﻿define(
   ({
    add: "Klicka för att lägga till ett nytt bokmärke.",
    title: "Titel",
    placeholderBookmarkName: "Namn på bokmärke",
    ok: "OK",
    cancel: "Avbryt",
    warning: "Slutför redigeringen!",
    edit: "Redigera bokmärke",
    errorNameExist: "Det finns ett bokmärke!",
    errorNameNull: "Ogiltigt namn på bokmärke!",
    addBookmark: "Skapa ett nytt bokmärke",
    thumbnail: "Miniatyrbild",
    thumbnailHint: "Klicka på bilden för att uppdatera"
  })
);