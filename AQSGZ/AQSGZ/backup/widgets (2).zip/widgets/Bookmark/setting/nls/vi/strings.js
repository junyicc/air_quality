﻿define(
   ({
    add: "Bấm để Thêm Đánh dấu Mới",
    title: "Tiêu đề",
    placeholderBookmarkName: "Tên Đánh dấu",
    ok: "OK",
    cancel: "Hủy",
    warning: "Vui lòng kết thúc chỉnh sửa!",
    edit: "Chỉnh sửa đánh dấu",
    errorNameExist: "Đánh dấu đã tồn tại!",
    errorNameNull: "Tên đánh dấu không hợp lệ!",
    addBookmark: "Tạo một Đánh dấu Mới",
    thumbnail: "Hình thu nhỏ",
    thumbnailHint: "Bấm vào hình ảnh để cập nhật"
  })
);