﻿define(
   ({
    add: "Noklikšķiniet, lai pievienotu jaunu grāmatzīmi",
    title: "Nosaukums",
    placeholderBookmarkName: "Grāmatzīmes nosaukums",
    ok: "Labi",
    cancel: "Atcelt",
    warning: "Pabeidziet rediģēšanu!",
    edit: "Rediģēt grāmatzīmi",
    errorNameExist: "Grāmatzīme pastāv!",
    errorNameNull: "Nederīgs grāmatzīmes nosaukums.",
    addBookmark: "Izveidot jaunu grāmatzīmi",
    thumbnail: "Sīktēls",
    thumbnailHint: "Noklikšķiniet uz attēla, lai atjauninātu"
  })
);