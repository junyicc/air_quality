﻿define(
   ({
    add: "Kliknij, aby dodać nową zakładkę",
    title: "Tytuł",
    placeholderBookmarkName: "Nazwa zakładki",
    ok: "OK",
    cancel: "Anuluj",
    warning: "Należy zakończyć edycję!",
    edit: "Edytuj zakładkę",
    errorNameExist: "Zakładka już istnieje!",
    errorNameNull: "Nieprawidłowa nazwa zakładki!",
    addBookmark: "Utwórz nową zakładkę",
    thumbnail: "Miniatura",
    thumbnailHint: "Kliknij obraz do zaktualizowania"
  })
);