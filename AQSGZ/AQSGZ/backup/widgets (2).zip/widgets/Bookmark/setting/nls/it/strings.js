﻿define(
   ({
    add: "Fare clic per aggiungere un nuovo segnalibro",
    title: "Titolo",
    placeholderBookmarkName: "Nome segnalibro",
    ok: "OK",
    cancel: "Annulla",
    warning: "Completare la modifica.",
    edit: "Modifica segnalibro",
    errorNameExist: "Segnalibro esistente.",
    errorNameNull: "Nome segnalibro non valido.",
    addBookmark: "Crea un nuovo segnalibro",
    thumbnail: "Anteprima",
    thumbnailHint: "Fare clic sull\'immagine per aggiornare"
  })
);