﻿define(
   ({
    _widgetLabel: "Sākuma poga"
  })
);