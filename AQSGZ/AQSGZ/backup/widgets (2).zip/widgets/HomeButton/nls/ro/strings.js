﻿define(
   ({
    _widgetLabel: "Buton Pagina principală"
  })
);