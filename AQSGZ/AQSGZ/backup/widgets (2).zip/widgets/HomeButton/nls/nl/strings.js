﻿define(
   ({
    _widgetLabel: "Home-knop"
  })
);