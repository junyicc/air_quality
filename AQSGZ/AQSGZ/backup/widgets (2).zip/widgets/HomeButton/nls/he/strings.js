﻿define(
   ({
    _widgetLabel: "לחצן דף הבית"
  })
);