﻿define(
   ({
    _widgetLabel: "Hjem-knapp"
  })
);