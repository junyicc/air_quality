﻿define(
   ({
    _widgetLabel: "Schaltfläche \"Startseite\""
  })
);