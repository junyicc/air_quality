﻿define(
   ({
    _widgetLabel: "Przycisk Start"
  })
);