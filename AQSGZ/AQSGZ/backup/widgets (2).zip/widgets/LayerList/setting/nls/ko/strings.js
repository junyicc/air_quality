﻿define(
   ({
    showLegend: "범례 표시"
  })
);