﻿define(
   ({
    showLegend: "Hiển thị Chú giải"
  })
);