﻿define(
   ({
    showLegend: "Zobrazit legendu"
  })
);