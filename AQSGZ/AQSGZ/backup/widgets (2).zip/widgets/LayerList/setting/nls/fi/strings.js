﻿define(
   ({
    showLegend: "Näytä selite"
  })
);