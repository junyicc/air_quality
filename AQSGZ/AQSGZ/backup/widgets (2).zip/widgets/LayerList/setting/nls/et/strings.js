﻿define(
   ({
    showLegend: "Näita legendi"
  })
);