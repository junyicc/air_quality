﻿define(
   ({
    showLegend: "إظهار وسيلة الإيضاح"
  })
);