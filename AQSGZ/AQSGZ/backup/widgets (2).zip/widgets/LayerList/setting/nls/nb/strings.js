﻿define(
   ({
    showLegend: "Vis tegnforklaring"
  })
);