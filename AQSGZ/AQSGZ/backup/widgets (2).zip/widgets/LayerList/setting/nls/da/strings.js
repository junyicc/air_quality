﻿define(
   ({
    showLegend: "Vis signaturforklaring"
  })
);