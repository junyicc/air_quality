﻿define(
   ({
    showLegend: "Εμφάνιση υπομνήματος"
  })
);