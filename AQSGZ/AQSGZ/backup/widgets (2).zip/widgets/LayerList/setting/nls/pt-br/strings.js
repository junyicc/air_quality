﻿define(
   ({
    showLegend: "Mostrar legenda"
  })
);