﻿define(
   ({
    showLegend: "Visa förklaring"
  })
);