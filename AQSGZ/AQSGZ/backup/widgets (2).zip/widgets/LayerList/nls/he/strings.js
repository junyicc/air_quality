﻿define(
   ({
    _widgetLabel: "רשימת שכבות",
    titleBasemap: "מפות בסיס",
    titleLayers: "שכבות תפעוליות",
    labelLayer: "שם שכבה",
    itemZoomTo: "התמקד אל",
    itemTransparency: "שקיפות",
    itemTransparent: "שקוף",
    itemOpaque: "אטום",
    itemMoveUp: "הזז למעלה",
    itemMoveDown: "הזז למטה",
    itemDesc: "תיאור",
    itemDownload: "הורדה",
    itemToAttributeTable: "פתח טבלת מאפיינים",
    itemShowItemDetails: "הצג פרטי פריט",
    empty: "ריק",
    removePopup: "‏‫הסר חלון קופץ‬",
    enablePopup: "הפעל חלון קופץ"
  })
);
