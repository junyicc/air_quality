﻿define(
   ({
    _widgetLabel: "レイヤー リスト",
    titleBasemap: "ベースマップ",
    titleLayers: "操作レイヤー",
    labelLayer: "レイヤー名",
    itemZoomTo: "ズーム",
    itemTransparency: "透過表示",
    itemTransparent: "透明",
    itemOpaque: "不透明",
    itemMoveUp: "上に移動",
    itemMoveDown: "下に移動",
    itemDesc: "説明",
    itemDownload: "ダウンロード",
    itemToAttributeTable: "属性テーブルを開く",
    itemShowItemDetails: "アイテムの詳細を表示",
    empty: "空",
    removePopup: "ポップアップの削除",
    enablePopup: "ポップアップの有効化"
  })
);
