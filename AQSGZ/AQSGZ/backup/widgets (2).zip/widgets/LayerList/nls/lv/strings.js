﻿define(
   ({
    _widgetLabel: "Slāņu saraksts",
    titleBasemap: "Pamatkartes",
    titleLayers: "Operacionālie slāņi",
    labelLayer: "Slāņa nosaukums",
    itemZoomTo: "Pietuvināt",
    itemTransparency: "Caurspīdīgums",
    itemTransparent: "Caurspīdīgs",
    itemOpaque: "Necaurredzams",
    itemMoveUp: "Pārvietot uz augšu",
    itemMoveDown: "Pārvietot uz leju",
    itemDesc: "Apraksts",
    itemDownload: "Lejupielāde",
    itemToAttributeTable: "Atvērt atribūtu tabulu",
    itemShowItemDetails: "Parādīt vienību detaļas",
    empty: "tukšs",
    removePopup: "Noņemt uznirstošo logu",
    enablePopup: "Aktivizēt uznirstošo logu"
  })
);
