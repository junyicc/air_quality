﻿define(
   ({
    _widgetLabel: "Список слоев",
    titleBasemap: "Базовые карты",
    titleLayers: "Рабочие слои",
    labelLayer: "Имя слоя",
    itemZoomTo: "Приблизить к",
    itemTransparency: "Прозрачность",
    itemTransparent: "Прозрачный",
    itemOpaque: "Непрозрачный",
    itemMoveUp: "Выше",
    itemMoveDown: "Ниже",
    itemDesc: "Описание",
    itemDownload: "Загрузить",
    itemToAttributeTable: "Открыть таблицу атрибутов",
    itemShowItemDetails: "Показать информацию об элементе",
    empty: "пусто",
    removePopup: "Удалить всплывающее окно",
    enablePopup: "Включить всплывающее окно"
  })
);
