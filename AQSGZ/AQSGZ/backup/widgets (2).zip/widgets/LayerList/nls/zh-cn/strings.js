﻿define(
   ({
    _widgetLabel: "图层列表",
    titleBasemap: "底图",
    titleLayers: "业务图层",
    labelLayer: "图层名称",
    itemZoomTo: "缩放至",
    itemTransparency: "透明度",
    itemTransparent: "透明",
    itemOpaque: "不透明",
    itemMoveUp: "上移",
    itemMoveDown: "下移",
    itemDesc: "描述",
    itemDownload: "下载",
    itemToAttributeTable: "打开属性表",
    itemShowItemDetails: "显示项目详细信息",
    empty: "空",
    removePopup: "移除弹出窗口",
    enablePopup: "启用弹出窗口"
  })
);
