﻿define(
   ({
    _widgetLabel: "รายการชั้นข้อมูล",
    titleBasemap: "แผนที่ฐาน",
    titleLayers: "ชั้นข้อมูลกระบวนการทำงาน",
    labelLayer: "ชื่อชั้นข้อมูล",
    itemZoomTo: "ขยายไปยัง",
    itemTransparency: "โปร่งแสง",
    itemTransparent: "โปร่งแสง",
    itemOpaque: "ทึบแสง",
    itemMoveUp: "เลื่อนขึ้น",
    itemMoveDown: "เลื่อนลง",
    itemDesc: "คำอธิบาย",
    itemDownload: "ดาวน์โหลด",
    itemToAttributeTable: "เปิดตารางข้อมูลคุณลักษณะ",
    itemShowItemDetails: "แสดงรายละเอียดข้อมูล",
    empty: "ว่าง",
    removePopup: "ลบป๊อปอัพ",
    enablePopup: "ใช้ป๊อปอัพ"
  })
);
