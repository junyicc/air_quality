﻿define(
   ({
    _widgetLabel: "Listă de straturi tematice",
    titleBasemap: "Hărţi fundal",
    titleLayers: "Straturi tematice operaţionale",
    labelLayer: "Nume strat tematic",
    itemZoomTo: "Transfocare la",
    itemTransparency: "Transparenţă",
    itemTransparent: "Transparent",
    itemOpaque: "Opac",
    itemMoveUp: "Deplasare în sus",
    itemMoveDown: "Deplasare în jos",
    itemDesc: "Descriere",
    itemDownload: "Descărcare",
    itemToAttributeTable: "Deschidere tabel de atribute",
    itemShowItemDetails: "Afişare detalii element",
    empty: "gol",
    removePopup: "Eliminare pop-up",
    enablePopup: "Activare pop-up"
  })
);
