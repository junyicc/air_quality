﻿define(
   ({
    _widgetLabel: "Lista warstw",
    titleBasemap: "Mapy bazowe",
    titleLayers: "Warstwy operacyjne",
    labelLayer: "Nazwa warstwy tematycznej",
    itemZoomTo: "Powiększ do",
    itemTransparency: "Przezroczystość",
    itemTransparent: "Przezroczysty",
    itemOpaque: "Nieprzezroczysty",
    itemMoveUp: "Przesuń w górę",
    itemMoveDown: "Przesuń w dół",
    itemDesc: "Opis",
    itemDownload: "Pobierz",
    itemToAttributeTable: "Otwórz tabelę atrybutów",
    itemShowItemDetails: "Pokaż szczegóły elementu",
    empty: "puste",
    removePopup: "Wyłącz okna podręczne",
    enablePopup: "Włącz okna podręczne"
  })
);
