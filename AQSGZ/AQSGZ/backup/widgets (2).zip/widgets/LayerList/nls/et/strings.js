﻿define(
   ({
    _widgetLabel: "Kihiloend",
    titleBasemap: "Aluskaardid",
    titleLayers: "Töökihid",
    labelLayer: "Kihi nimi",
    itemZoomTo: "Suumi",
    itemTransparency: "Läbipaistvus",
    itemTransparent: "Läbipaistev",
    itemOpaque: "Läbipaistmatu",
    itemMoveUp: "Liiguta ülespoole",
    itemMoveDown: "Liiguta allapoole",
    itemDesc: "Kirjeldus",
    itemDownload: "Laadi alla",
    itemToAttributeTable: "Ava atribuudi tabel",
    itemShowItemDetails: "Näita sisuobjekti detaile",
    empty: "tühi",
    removePopup: "Eemalda hüpikaken",
    enablePopup: "Luba hüpikaken"
  })
);
