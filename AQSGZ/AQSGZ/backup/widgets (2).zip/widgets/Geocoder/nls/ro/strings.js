﻿define(
   ({
    _widgetLabel: "Geocodificator",
    locationTitle: "Locaţie",
    notFound: "Locaţia „„${LOCATION}”” nu a putut fi găsită.",
    currentLocation: "Locaţie actuală",
    notWhatYouWanted: "Nu este ceea ce doreaţi?",
    selectAnother: "Selectaţi o altă locaţie"
  })
);