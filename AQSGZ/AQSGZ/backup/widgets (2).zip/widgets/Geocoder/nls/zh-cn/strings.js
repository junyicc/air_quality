﻿define(
   ({
    _widgetLabel: "地理编码器",
    locationTitle: "位置",
    notFound: "无法找到位置“${LOCATION}”。",
    currentLocation: "当前位置",
    notWhatYouWanted: "不是您想要的位置?",
    selectAnother: "选择其他位置"
  })
);