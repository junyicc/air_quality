﻿define(
   ({
    _widgetLabel: "Geokooderi",
    locationTitle: "Sijainti",
    notFound: "Sijaintia ${LOCATION} ei löydy.",
    currentLocation: "Nykyinen sijainti",
    notWhatYouWanted: "Etkö löytänyt etsimääsi?",
    selectAnother: "Valitse toinen sijainti"
  })
);