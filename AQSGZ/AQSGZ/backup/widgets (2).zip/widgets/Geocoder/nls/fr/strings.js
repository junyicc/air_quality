﻿define(
   ({
    _widgetLabel: "Géocodeur",
    locationTitle: "Emplacement",
    notFound: "L\'emplacement \'${LOCATION}\' est introuvable.",
    currentLocation: "Emplacement actuel",
    notWhatYouWanted: "Ce n\'est pas ce que vous vouliez ?",
    selectAnother: "Sélectionnez un autre emplacement"
  })
);