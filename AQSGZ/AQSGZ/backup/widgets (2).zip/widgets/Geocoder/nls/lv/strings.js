﻿define(
   ({
    _widgetLabel: "Ģeokodētājs",
    locationTitle: "Izvietojums",
    notFound: "Izvietojumu \'${LOCATION}\' nevarēja atrast.",
    currentLocation: "Pašreizējais izvietojums",
    notWhatYouWanted: "Nav tas, ko vēlējāties?",
    selectAnother: "Izvēlēties citu izvietojumu"
  })
);