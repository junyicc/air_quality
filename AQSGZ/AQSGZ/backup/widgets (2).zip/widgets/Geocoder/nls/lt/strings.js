﻿define(
   ({
    _widgetLabel: "Geokoderis",
    locationTitle: "Vieta",
    notFound: "Vietos \'${LOCATION}\' surasti nepavyko.",
    currentLocation: "Dabartinė vieta",
    notWhatYouWanted: "Ne tai ko norėjote?",
    selectAnother: "Pasirinkite kitą vietą"
  })
);