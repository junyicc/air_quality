﻿define(
   ({
    _widgetLabel: "Geocodificatore",
    locationTitle: "Posizione",
    notFound: "Impossibile trovare la posizione '${LOCATION}'.",
    currentLocation: "Posizione corrente",
    notWhatYouWanted: "Non è quanto desiderato?",
    selectAnother: "Selezionare un'altra posizione"
  })
);