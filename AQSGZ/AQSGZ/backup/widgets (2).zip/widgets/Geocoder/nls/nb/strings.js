﻿define(
   ({
    _widgetLabel: "Geokoder",
    locationTitle: "Plassering",
    notFound: "Finner ikke lokasjonen '${LOCATION}'",
    currentLocation: "Gjeldende plassering",
    notWhatYouWanted: "Ikke den du ville ha?",
    selectAnother: "Velg en annen lokasjon"
  })
);