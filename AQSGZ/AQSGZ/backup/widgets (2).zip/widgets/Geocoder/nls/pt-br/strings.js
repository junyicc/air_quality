﻿define(
   ({
    _widgetLabel: "Geocodificador",
    locationTitle: "Local",
    notFound: "Não foi possível encontrar o local '${LOCATION}'.",
    currentLocation: "Local atual",
    notWhatYouWanted: "Não é o que você desejava?",
    selectAnother: "Selecionar outro local"
  })
);