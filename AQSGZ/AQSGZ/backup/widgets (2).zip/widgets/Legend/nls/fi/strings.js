﻿define(
   ({
    _widgetLabel: "Selite"
  })
);