﻿define(
   ({
    _widgetLabel: "Legend"
  })
);