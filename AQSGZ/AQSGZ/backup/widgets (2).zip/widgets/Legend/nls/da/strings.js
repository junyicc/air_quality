﻿define(
   ({
    _widgetLabel: "Signaturforklaring"
  })
);