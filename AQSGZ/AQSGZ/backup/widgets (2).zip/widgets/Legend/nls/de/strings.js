﻿define(
   ({
    _widgetLabel: "Legende"
  })
);