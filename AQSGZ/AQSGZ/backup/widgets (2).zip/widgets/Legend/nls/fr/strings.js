﻿define(
   ({
    _widgetLabel: "Légende"
  })
);