﻿define(
   ({
    _widgetLabel: "Legenda"
  })
);