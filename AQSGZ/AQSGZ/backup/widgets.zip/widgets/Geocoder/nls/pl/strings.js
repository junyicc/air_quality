﻿define(
   ({
    _widgetLabel: "Geokoder",
    locationTitle: "Lokalizacja",
    notFound: "Nie można odnaleźć lokalizacji '${LOCATION}'.",
    currentLocation: "Bieżąca lokalizacja",
    notWhatYouWanted: "Oczekiwano innej lokalizacji?",
    selectAnother: "Wybierz inną lokalizację"
  })
);