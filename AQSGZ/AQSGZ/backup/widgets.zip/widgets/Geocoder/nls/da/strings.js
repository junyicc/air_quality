﻿define(
   ({
    _widgetLabel: "Geokoder",
    locationTitle: "Sted",
    notFound: "Sted '${LOCATION}' kunne ikke findes.",
    currentLocation: "Aktuel placering",
    notWhatYouWanted: "Var det ikke det, du ville?",
    selectAnother: "Vælg et andet sted"
  })
);