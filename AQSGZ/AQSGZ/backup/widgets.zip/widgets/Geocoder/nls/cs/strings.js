﻿define(
   ({
    _widgetLabel: "Geokodér",
    locationTitle: "Umístění",
    notFound: "Umístění \'${LOCATION}\' se nepodařilo nalézt.",
    currentLocation: "Aktuální umístění",
    notWhatYouWanted: "Nenašli jste, co jste hledali?",
    selectAnother: "Vybrat jiné umístění"
  })
);