﻿define(
   ({
    _widgetLabel: "Geokodare",
    locationTitle: "Plats",
    notFound: "Det gick inte att hitta platsen ${LOCATION}.",
    currentLocation: "Aktuell plats",
    notWhatYouWanted: "Är det inte vad du vill ha?",
    selectAnother: "Välj en annan plats"
  })
);