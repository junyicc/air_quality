﻿define(
   ({
    _widgetLabel: "ジオコーダー",
    locationTitle: "位置",
    notFound: "位置 '${LOCATION}' が見つかりませんでした。",
    currentLocation: "現在の位置",
    notWhatYouWanted: "他の住所の候補を表示しますか？",
    selectAnother: "他の候補を選択"
  })
);