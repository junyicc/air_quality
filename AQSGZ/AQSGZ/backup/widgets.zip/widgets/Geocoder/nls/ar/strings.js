﻿define(
   ({
    _widgetLabel: "المُكود الجغرافي",
    locationTitle: "الموقع",
    notFound: "لم يتم العثور على موقع '${LOCATION}'.",
    currentLocation: "الموقع الحالي",
    notWhatYouWanted: "هل هذا ليس ما تريده؟",
    selectAnother: "تحديد موقع آخر"
  })
);