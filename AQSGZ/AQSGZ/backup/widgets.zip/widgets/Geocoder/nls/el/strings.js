﻿define(
   ({
    _widgetLabel: "Γεωκωδικοποίηση",
    locationTitle: "Τοποθεσία",
    notFound: "Δεν ήταν δυνατή η εύρεση της τοποθεσίας '${LOCATION}'.",
    currentLocation: "Τρέχουσα τοποθεσία",
    notWhatYouWanted: "Δεν είναι αυτή που θέλετε;",
    selectAnother: "Επιλέξτε άλλη τοποθεσία"
  })
);