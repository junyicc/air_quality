﻿define(
   ({
    showLegend: "Pokaż legendę"
  })
);