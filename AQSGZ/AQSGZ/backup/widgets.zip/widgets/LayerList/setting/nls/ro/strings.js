﻿define(
   ({
    showLegend: "Afişare legendă"
  })
);