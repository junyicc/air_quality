﻿define(
   ({
    showLegend: "Exibir legenda"
  })
);