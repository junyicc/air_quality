﻿define(
   ({
    showLegend: "Legenda weergeven"
  })
);