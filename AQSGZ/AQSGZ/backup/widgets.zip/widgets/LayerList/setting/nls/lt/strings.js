﻿define(
   ({
    showLegend: "Rodyti legendą"
  })
);