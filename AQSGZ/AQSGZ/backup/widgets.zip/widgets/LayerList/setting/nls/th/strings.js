﻿define(
   ({
    showLegend: "แสดงคำอธิบายสัญลักษณ์"
  })
);