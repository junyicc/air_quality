﻿define(
   ({
    showLegend: "Legende anzeigen"
  })
);