﻿define(
   ({
    showLegend: "Показать легенду"
  })
);