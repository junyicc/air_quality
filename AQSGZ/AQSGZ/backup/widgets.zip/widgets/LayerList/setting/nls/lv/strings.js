﻿define(
   ({
    showLegend: "Rādīt leģendu"
  })
);