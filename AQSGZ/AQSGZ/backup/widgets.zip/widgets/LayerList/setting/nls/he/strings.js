﻿define(
   ({
    showLegend: "הצג מקרא"
  })
);