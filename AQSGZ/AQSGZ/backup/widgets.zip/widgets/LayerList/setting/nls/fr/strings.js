﻿define(
   ({
    showLegend: "Afficher la légende"
  })
);