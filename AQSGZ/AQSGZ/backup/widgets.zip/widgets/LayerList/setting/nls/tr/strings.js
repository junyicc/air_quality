﻿define(
   ({
    showLegend: "Gösterimi Göster"
  })
);