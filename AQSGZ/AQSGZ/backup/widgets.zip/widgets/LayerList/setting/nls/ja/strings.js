﻿define(
   ({
    showLegend: "凡例を表示"
  })
);