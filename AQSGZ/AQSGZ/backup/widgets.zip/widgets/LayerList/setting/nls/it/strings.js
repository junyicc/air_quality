﻿define(
   ({
    showLegend: "Mostra legenda"
  })
);