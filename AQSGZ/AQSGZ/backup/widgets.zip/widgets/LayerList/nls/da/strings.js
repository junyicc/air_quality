﻿define(
   ({
    _widgetLabel: "Lagliste",
    titleBasemap: "Baggrundskort",
    titleLayers: "Operationelle lag",
    labelLayer: "Navn på lag",
    itemZoomTo: "Zoom til",
    itemTransparency: "Gennemsigtighed",
    itemTransparent: "Gennemsigtig",
    itemOpaque: "Uigennemsigtig",
    itemMoveUp: "Flyt op",
    itemMoveDown: "Flyt ned",
    itemDesc: "Beskrivelse",
    itemDownload: "Hent",
    itemToAttributeTable: "Åbn attributtabel",
    itemShowItemDetails: "Vil elementoplysninger",
    empty: "tom",
    removePopup: "Fjern pop-up",
    enablePopup: "Aktivér pop-up"
  })
);
