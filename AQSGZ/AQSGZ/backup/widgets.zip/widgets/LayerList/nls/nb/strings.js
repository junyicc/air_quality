﻿define(
   ({
    _widgetLabel: "Kartlagliste",
    titleBasemap: "Bakgrunnskart",
    titleLayers: "Operative kartlag",
    labelLayer: "Lagnavn",
    itemZoomTo: "Zoom til",
    itemTransparency: "Gjennomsiktighet",
    itemTransparent: "Gjennomsiktighet",
    itemOpaque: "Ugjennomsiktig",
    itemMoveUp: "Flytt opp",
    itemMoveDown: "Flytt ned",
    itemDesc: "Beskrivelse",
    itemDownload: "Last ned",
    itemToAttributeTable: "Åpne attributtabell",
    itemShowItemDetails: "Vis elementdetaljene",
    empty: "tom",
    removePopup: "Fjern popup",
    enablePopup: "Aktiver popup"
  })
);
