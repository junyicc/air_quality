﻿define(
   ({
    _widgetLabel: "Lijst met lagen",
    titleBasemap: "Basiskaarten",
    titleLayers: "Operationele lagen",
    labelLayer: "Laagnaam",
    itemZoomTo: "Zoomen naar",
    itemTransparency: "Transparant",
    itemTransparent: "Transparant",
    itemOpaque: "Niet transparant",
    itemMoveUp: "Naar boven verplaatsen",
    itemMoveDown: "Naar beneden verplaatsen",
    itemDesc: "Beschrijving",
    itemDownload: "Downloaden",
    itemToAttributeTable: "Attribuuttabel openen",
    itemShowItemDetails: "Itemdetails weergeven",
    empty: "leeg",
    removePopup: "Pop-up verwijderen",
    enablePopup: "Pop-up inschakelen"
  })
);
