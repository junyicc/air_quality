﻿define(
   ({
    _widgetLabel: "Lista de Camadas",
    titleBasemap: "Mapas base",
    titleLayers: "Camadas Operacionais",
    labelLayer: "Nome da Camada",
    itemZoomTo: "Efetuar zoom para",
    itemTransparency: "Transparência",
    itemTransparent: "Transparente",
    itemOpaque: "Opaco",
    itemMoveUp: "Mover para cima",
    itemMoveDown: "Mover para baixo",
    itemDesc: "Descrição",
    itemDownload: "Descarregar",
    itemToAttributeTable: "Abrir tabela de atributos",
    itemShowItemDetails: "Mostrar Detalhes do Item",
    empty: "vazio",
    removePopup: "Remover Janela Pop-up",
    enablePopup: "Ativar Janela Pop-up"
  })
);
