﻿define(
   ({
    _widgetLabel: "Katman Listesi",
    titleBasemap: "Altlık haritaları",
    titleLayers: "Operasyonel Katmanlar",
    labelLayer: "Katman Adı",
    itemZoomTo: "Şuna Yakınlaştır",
    itemTransparency: "Saydamlık",
    itemTransparent: "Saydam",
    itemOpaque: "Opak",
    itemMoveUp: "Yukarı taşı",
    itemMoveDown: "Aşağı taşı",
    itemDesc: "Açıklama",
    itemDownload: "İndir",
    itemToAttributeTable: "Öznitelik Tablosunu Aç",
    itemShowItemDetails: "Öğe Ayrıntılarını Göster",
    empty: "boş",
    removePopup: "Açılan Pencereyi Kaldır",
    enablePopup: "Açılan Pencereyi Etkinleştir"
  })
);
