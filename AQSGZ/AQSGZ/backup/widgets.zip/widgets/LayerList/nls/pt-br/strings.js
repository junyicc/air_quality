﻿define(
   ({
    _widgetLabel: "Lista de Camada",
    titleBasemap: "Mapas Base",
    titleLayers: "Camadas Operacionais",
    labelLayer: "Nome da Camada",
    itemZoomTo: "Zoom para",
    itemTransparency: "Transparência",
    itemTransparent: "Transparente",
    itemOpaque: "Opaco",
    itemMoveUp: "Mover para cima",
    itemMoveDown: "Mover para baixo",
    itemDesc: "Descrição",
    itemDownload: "Download",
    itemToAttributeTable: "Abrir Tabela de Atributo",
    itemShowItemDetails: "Mostrar Detalhes do Item",
    empty: "vazio",
    removePopup: "Remover Pop-up",
    enablePopup: "Habilitar Pop-up"
  })
);
