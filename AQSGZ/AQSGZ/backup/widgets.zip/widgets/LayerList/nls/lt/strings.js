﻿define(
   ({
    _widgetLabel: "Sluoksniai",
    titleBasemap: "Pagrindo žemėlapiai",
    titleLayers: "Darbiniai sluoksniai",
    labelLayer: "Sluoksnio pavadinimas",
    itemZoomTo: "Parodyti visą",
    itemTransparency: "Permatomumas",
    itemTransparent: "Permatomas",
    itemOpaque: "Nepermatomas",
    itemMoveUp: "Pakelti aukštyn",
    itemMoveDown: "Nuleisti žemyn",
    itemDesc: "Aprašas",
    itemDownload: "Atsiųsti",
    itemToAttributeTable: "Atidaryti atributų lentelę",
    itemShowItemDetails: "Rodyti elemento aprašą",
    empty: "tuščia",
    removePopup: "Pašalinti iškylančius langus",
    enablePopup: "Įjungti iškylančius langus"
  })
);
