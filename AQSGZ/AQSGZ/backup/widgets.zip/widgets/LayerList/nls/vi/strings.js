﻿define(
   ({
    _widgetLabel: "Danh sách Lớp",
    titleBasemap: "Bản đồ nền",
    titleLayers: "Các lớp hoạt động",
    labelLayer: "Tên lớp",
    itemZoomTo: "Phóng tới",
    itemTransparency: "Độ trong suốt",
    itemTransparent: "Độ trong suốt",
    itemOpaque: "Độ mờ",
    itemMoveUp: "Di chuyển lên trên",
    itemMoveDown: "Di chuyển xuống dưới",
    itemDesc: "Mô tả",
    itemDownload: "Tải xuống",
    itemToAttributeTable: "Mở Bảng Thuộc tính",
    itemShowItemDetails: "Hiện Chi tiết của Mục",
    empty: "trống",
    removePopup: "Ẩn cửa sổ pop-up",
    enablePopup: "Bật Cửa sổ pop-up"
  })
);
