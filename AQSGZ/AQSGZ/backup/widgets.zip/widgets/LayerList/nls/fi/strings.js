﻿define(
   ({
    _widgetLabel: "Karttatasot",
    titleBasemap: "Taustakartat",
    titleLayers: "Toiminnalliset karttatasot",
    labelLayer: "Karttatason nimi",
    itemZoomTo: "Tarkenna kohteeseen",
    itemTransparency: "Läpinäkyvyys",
    itemTransparent: "Läpinäkyvä",
    itemOpaque: "Läpinäkymätön",
    itemMoveUp: "Siirrä ylös",
    itemMoveDown: "Siirrä alas",
    itemDesc: "Kuvaus",
    itemDownload: "Lataa",
    itemToAttributeTable: "Avaa ominaisuustietotaulu",
    itemShowItemDetails: "Näytä kohteen tiedot",
    empty: "tyhjä",
    removePopup: "Poista ponnahdusikkuna",
    enablePopup: "Ota ponnahdusikkunat käyttöön"
  })
);
