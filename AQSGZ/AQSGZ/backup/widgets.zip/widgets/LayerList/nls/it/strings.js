﻿define(
   ({
    _widgetLabel: "Elenco layer",
    titleBasemap: "Mappe di base",
    titleLayers: "Layer operativi",
    labelLayer: "Nome layer",
    itemZoomTo: "Zoom a",
    itemTransparency: "Trasparenza",
    itemTransparent: "Trasparente",
    itemOpaque: "Opaco",
    itemMoveUp: "Sposta su",
    itemMoveDown: "Sposta giù",
    itemDesc: "Descrizione",
    itemDownload: "Download",
    itemToAttributeTable: "Apri tabella attributi",
    itemShowItemDetails: "Mostra dettagli elemento",
    empty: "vuoto",
    removePopup: "Rimuovi popup",
    enablePopup: "Abilita popup"
  })
);
