﻿define(
   ({
    _widgetLabel: "레이어 목록",
    titleBasemap: "베이스맵",
    titleLayers: "운영 레이어",
    labelLayer: "레이어 이름",
    itemZoomTo: "확대",
    itemTransparency: "투명도",
    itemTransparent: "투명",
    itemOpaque: "불투명",
    itemMoveUp: "위로 이동",
    itemMoveDown: "아래로 이동",
    itemDesc: "설명",
    itemDownload: "다운로드",
    itemToAttributeTable: "속성 테이블 열기",
    itemShowItemDetails: "항목 세부정보 보기",
    empty: "비어 있음",
    removePopup: "팝업 제거",
    enablePopup: "팝업 활성화"
  })
);
