﻿define(
   ({
    labelBookmarkName: "Установить закладку на текущем виде",
    labelPlay: "Воспроизвести всё",
    labelStop: "Стоп",
    labelDelete: "Удалить",
    placeholderBookmarkName: "Имя закладки",
    errorNameExist: "Закладка уже существует!",
    errorNameNull: "Недопустимое имя закладки!",
    _widgetLabel: "Закладка"
  })
);