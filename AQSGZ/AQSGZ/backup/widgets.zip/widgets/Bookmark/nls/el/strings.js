﻿define(
   ({
    labelBookmarkName: "Προσθήκη σελιδοδείκτη στην τρέχουσα προβολή",
    labelPlay: "Αναπαραγωγή όλων",
    labelStop: "Παύση",
    labelDelete: "Διαγραφή",
    placeholderBookmarkName: "Όνομα σελιδοδείκτη",
    errorNameExist: "Ο σελιδοδείκτης υπάρχει!",
    errorNameNull: "Μη έγκυρο όνομα σελιδοδείκτη!",
    _widgetLabel: "Σελιδοδείκτης"
  })
);