﻿define(
   ({
    labelBookmarkName: "Đánh dấu tầm nhìn hiện tại",
    labelPlay: "Phát Tất cả",
    labelStop: "Dừng",
    labelDelete: "Xóa",
    placeholderBookmarkName: "Tên Đánh dấu",
    errorNameExist: "Đánh dấu đã tồn tại!",
    errorNameNull: "Tên đánh dấu không hợp lệ!",
    _widgetLabel: "Đánh dấu"
  })
);