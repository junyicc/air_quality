﻿define(
   ({
    labelBookmarkName: "Kirjamerkitse nykyinen näkymä",
    labelPlay: "Toista kaikki",
    labelStop: "Lopeta",
    labelDelete: "Poista",
    placeholderBookmarkName: "Kirjanmerkin nimi",
    errorNameExist: "Kirjanmerkki on olemassa!",
    errorNameNull: "Kirjanmerkin nimi on virheellinen!",
    _widgetLabel: "Kirjanmerkki"
  })
);