﻿define(
   ({
    labelBookmarkName: "Přidat aktuální zobrazení do záložek",
    labelPlay: "Přehrát vše",
    labelStop: "Zastavit",
    labelDelete: "Smazat",
    placeholderBookmarkName: "Název záložky",
    errorNameExist: "Záložka již existuje!",
    errorNameNull: "Neplatný název záložky!",
    _widgetLabel: "Záložka"
  })
);