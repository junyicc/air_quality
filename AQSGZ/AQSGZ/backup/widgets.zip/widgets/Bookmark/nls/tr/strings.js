﻿define(
   ({
    labelBookmarkName: "Geçerli görünümü yer işaretlerine ekle",
    labelPlay: "Tümünü Oynat",
    labelStop: "Durdur",
    labelDelete: "Sil",
    placeholderBookmarkName: "Yer İşareti Adı",
    errorNameExist: "Yer işareti mevcut!",
    errorNameNull: "Geçersiz yer işareti adı!",
    _widgetLabel: "Yer İmi"
  })
);