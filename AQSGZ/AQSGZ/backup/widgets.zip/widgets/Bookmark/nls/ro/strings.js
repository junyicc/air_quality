﻿define(
   ({
    labelBookmarkName: "Marcaţi vizualizarea curentă",
    labelPlay: "Redare toate",
    labelStop: "Oprire",
    labelDelete: "Ştergere",
    placeholderBookmarkName: "Nume marcaj",
    errorNameExist: "Marcajul există!",
    errorNameNull: "Nume marcaj nevalid!",
    _widgetLabel: "Semn de carte"
  })
);