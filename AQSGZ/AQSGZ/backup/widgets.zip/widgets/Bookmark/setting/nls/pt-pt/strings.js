﻿define(
   ({
    add: "Clicar para Adicionar um Novo Marcador",
    title: "Título",
    placeholderBookmarkName: "Nome do Marcador",
    ok: "Ok",
    cancel: "Cancelar",
    warning: "Por favor termine a edição!",
    edit: "Editar marcador",
    errorNameExist: "O Marcador existe!",
    errorNameNull: "Nome de marcador inválido!",
    addBookmark: "Criar um Novo Marcador",
    thumbnail: "Miniatura",
    thumbnailHint: "Clique na imagem para atualizar"
  })
);