﻿define(
   ({
    add: "Klik for at tilføje et nyt bogmærke",
    title: "Titel",
    placeholderBookmarkName: "Bogmærkenavn",
    ok: "OK",
    cancel: "Annuller",
    warning: "Færdiggør redigeringen!",
    edit: "Rediger bogmærke",
    errorNameExist: "Bogmærket findes!",
    errorNameNull: "Ugyldigt bogmærkenavn!",
    addBookmark: "Opret et nyt bogmærke",
    thumbnail: "Miniature",
    thumbnailHint: "Klik på billedet for at opdatere"
  })
);