﻿define(
   ({
    add: "Klikk for å legge til et nytt bokmerke",
    title: "Tittel",
    placeholderBookmarkName: "Bokmerkenavn",
    ok: "OK",
    cancel: "Avbryt",
    warning: "Fullfør redigeringen!",
    edit: "Rediger bokmerke",
    errorNameExist: "Bokmerket eksisterer.",
    errorNameNull: "Ugyldig bokmerkenavn.",
    addBookmark: "Opprett et nytt bokmerke",
    thumbnail: "Miniatyrbilde",
    thumbnailHint: "Klikk på bildet for å oppdatere"
  })
);