﻿define(
   ({
    add: "Klik om een nieuwe bladwijzer toe te voegen",
    title: "Titel",
    placeholderBookmarkName: "Naam van bladwijzer",
    ok: "OK",
    cancel: "Afbreken",
    warning: "Bewerking voltooien!",
    edit: "Bladwijzer bewerken",
    errorNameExist: "Bladwijzer bestaat al.",
    errorNameNull: "Ongeldige naam van bladwijzer.",
    addBookmark: "Een nieuwe bladwijzer maken",
    thumbnail: "Thumbnail",
    thumbnailHint: "Klik op de afbeelding om deze te bewerken"
  })
);