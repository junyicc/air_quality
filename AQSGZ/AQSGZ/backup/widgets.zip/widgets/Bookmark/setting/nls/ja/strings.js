﻿define(
   ({
    add: "クリックすると新規ベースマップが追加されます",
    title: "タイトル",
    placeholderBookmarkName: "ブックマーク名",
    ok: "OK",
    cancel: "キャンセル",
    warning: "編集を終了してください。",
    edit: "ブックマークの編集",
    errorNameExist: "すでに存在しているブックマーク名です",
    errorNameNull: "無効なブックマーク名です",
    addBookmark: "ブックマークの新規作成",
    thumbnail: "サムネイル",
    thumbnailHint: "画像をクリックすると更新されます"
  })
);