﻿define(
   ({
    add: "לחץ להוספת סימניה חדשה",
    title: "כותרת",
    placeholderBookmarkName: "שם סימניה",
    ok: "אישור",
    cancel: "ביטול",
    warning: "סיים בקשה את העריכה!",
    edit: "ערוך סימניה",
    errorNameExist: "סימניה קיימת!",
    errorNameNull: "שם סימניה לא חוקי!",
    addBookmark: "צור סימניה חדשה",
    thumbnail: "תמונה ממוזערת",
    thumbnailHint: "לחץ על התמונה לעדכון"
  })
);