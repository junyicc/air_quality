﻿define(
   ({
    add: "Щелкните, чтобы добавить новую закладку",
    title: "Название",
    placeholderBookmarkName: "Имя закладки",
    ok: "OK",
    cancel: "Отмена",
    warning: "Завершите редактирование!",
    edit: "Изменить закладку",
    errorNameExist: "Закладка уже существует!",
    errorNameNull: "Недопустимое имя закладки!",
    addBookmark: "Создать новую закладку",
    thumbnail: "Образец",
    thumbnailHint: "Щелкните на изображении, чтобы обновить его"
  })
);