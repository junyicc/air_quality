﻿define(
   ({
    add: "Zum Hinzufügen eines neuen Lesezeichens klicken",
    title: "Titel",
    placeholderBookmarkName: "Lesezeichenname",
    ok: "OK",
    cancel: "Abbrechen",
    warning: "Beenden Sie die Bearbeitung!",
    edit: "Lesezeichen bearbeiten",
    errorNameExist: "Lesezeichen ist vorhanden!",
    errorNameNull: "Ungültiger Lesezeichenname!",
    addBookmark: "Neues Lesezeichen erstellen",
    thumbnail: "Miniaturansicht",
    thumbnailHint: "Zum Aktualisieren auf das Bild klicken"
  })
);