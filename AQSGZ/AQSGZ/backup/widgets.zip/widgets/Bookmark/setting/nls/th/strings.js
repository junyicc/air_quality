﻿define(
   ({
    add: "คลิกเพื่อแอพบุคมาร์คใหม่",
    title: "ชื่อเรื่อง",
    placeholderBookmarkName: "ตั้งชื่อบุคมาร์ค",
    ok: "ตกลง",
    cancel: "ยกเลิก",
    warning: "โปรดแก้ไขให้เรียบร้อย!",
    edit: "แก้ไขบุคมาร์ค",
    errorNameExist: "บุคมาร์คมีอยู่แล้ว!",
    errorNameNull: "ชื่อบุคมาร์คไม่ถูกต้อง!",
    addBookmark: "สร้างบุคมาร์คใหม่",
    thumbnail: "รูปภาพขนาดเล็ก",
    thumbnailHint: "คลิกที่รูปภาพเพื่ออัพเดท"
  })
);