﻿define(
   ({
    add: "Yeni bir Yer imi eklemek için Tıkla",
    title: "Başlık",
    placeholderBookmarkName: "Yer İşareti Adı",
    ok: "Tamam",
    cancel: "İptal",
    warning: "Düzenlemeyi tamamlayın!",
    edit: "Yer işaretlerini düzenle",
    errorNameExist: "Yer işareti mevcut!",
    errorNameNull: "Geçersiz yer işareti adı!",
    addBookmark: "Yeni Yer İşareti Oluştur",
    thumbnail: "Küçük Resim",
    thumbnailHint: "Güncellemek için resme tıkla"
  })
);