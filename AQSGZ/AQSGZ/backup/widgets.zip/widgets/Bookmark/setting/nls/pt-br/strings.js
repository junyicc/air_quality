﻿define(
   ({
    add: "Clique para Adicionar um Novo Marcador",
    title: "Título",
    placeholderBookmarkName: "Nome do Marcador",
    ok: "Ok",
    cancel: "Cancelar",
    warning: "Finalize a edição!",
    edit: "Editar marcador",
    errorNameExist: "O marcador existe!",
    errorNameNull: "Nome de marcador inválido!",
    addBookmark: "Criar um Novo Marcador",
    thumbnail: "Miniatura",
    thumbnailHint: "Clique na imagem para atualizar"
  })
);