﻿define(
   ({
    add: "Cliquez pour ajouter un nouveau géosignet",
    title: "Titre",
    placeholderBookmarkName: "Nom du géosignet",
    ok: "OK",
    cancel: "Annuler",
    warning: "Terminez la modification !",
    edit: "Modifier le géosignet",
    errorNameExist: "Le géosignet existe !",
    errorNameNull: "Nom de géosignet non valide !",
    addBookmark: "Créer un géosignet",
    thumbnail: "Miniature",
    thumbnailHint: "Cliquez sur l\'image pour la mettre à jour"
  })
);