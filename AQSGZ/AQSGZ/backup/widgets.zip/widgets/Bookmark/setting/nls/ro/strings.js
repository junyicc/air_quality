﻿define(
   ({
    add: "Faceţi clic pe Adăugare semn de carte nou",
    title: "Titlu",
    placeholderBookmarkName: "Nume marcaj",
    ok: "OK",
    cancel: "Anulare",
    warning: "Finalizaţi editarea!",
    edit: "Editare semn de carte",
    errorNameExist: "Marcajul există!",
    errorNameNull: "Nume marcaj nevalid!",
    addBookmark: "Creare marcaj nou",
    thumbnail: "Miniatură",
    thumbnailHint: "Faceţi clic pe imagine pentru a o actualiza"
  })
);