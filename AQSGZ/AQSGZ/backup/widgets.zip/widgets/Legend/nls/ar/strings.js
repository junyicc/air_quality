﻿define(
   ({
    _widgetLabel: "وسيلة إيضاح"
  })
);