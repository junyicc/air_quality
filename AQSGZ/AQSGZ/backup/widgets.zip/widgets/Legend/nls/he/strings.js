﻿define(
   ({
    _widgetLabel: "מקרא"
  })
);