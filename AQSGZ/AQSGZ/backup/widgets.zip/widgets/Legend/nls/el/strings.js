﻿define(
   ({
    _widgetLabel: "Υπόμνημα"
  })
);