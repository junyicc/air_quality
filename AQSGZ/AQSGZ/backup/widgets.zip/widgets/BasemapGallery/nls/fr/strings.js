﻿define(
   ({
    _widgetLabel: "Bibliothèque de fonds de carte"
  })
);