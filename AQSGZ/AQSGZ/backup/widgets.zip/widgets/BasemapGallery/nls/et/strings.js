﻿define(
   ({
    _widgetLabel: "Aluskaardi galerii"
  })
);