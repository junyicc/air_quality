﻿define(
   ({
    _widgetLabel: "แกลเลอรี่แผนที่ฐาน"
  })
);