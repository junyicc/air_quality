﻿define(
   ({
    _widgetLabel: "HomeButton"
  })
);