﻿define(
   ({
    _widgetLabel: "Кнопка На главную"
  })
);