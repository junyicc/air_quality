﻿define(
   ({
    _widgetLabel: "Botão Página Inicial"
  })
);