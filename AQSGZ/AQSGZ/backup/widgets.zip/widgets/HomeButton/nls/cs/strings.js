﻿define(
   ({
    _widgetLabel: "Tlačítko Domů"
  })
);