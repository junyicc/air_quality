﻿define(
   ({
    _widgetLabel: "Ana Sayfa Düğmesi"
  })
);