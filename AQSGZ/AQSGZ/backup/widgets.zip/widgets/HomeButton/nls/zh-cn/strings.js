﻿define(
   ({
    _widgetLabel: "主目录按钮"
  })
);