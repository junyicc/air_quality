﻿define(
   ({
    _widgetLabel: "Kotisivu-painike"
  })
);