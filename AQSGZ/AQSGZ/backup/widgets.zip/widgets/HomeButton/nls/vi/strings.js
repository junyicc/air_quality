﻿define(
   ({
    _widgetLabel: "Nút Trang chủ"
  })
);