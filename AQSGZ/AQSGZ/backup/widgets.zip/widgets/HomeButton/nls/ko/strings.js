﻿define(
   ({
    _widgetLabel: "홈 버튼"
  })
);